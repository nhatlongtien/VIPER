//
//  Bundle+Extension.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
extension Bundle{
    var releaseVersionNumber: String {
        guard let version = infoDictionary?["CFBundleShortVersionString"] as? String else {
            return "unknow"
        }
        return version
    }
    var buildVersionNumber: String {
        guard let buildVersion = infoDictionary?["CFBundleVersion"] as? String else {
            return "unknow"
        }
        return buildVersion
    }
    
    var osVersion:String{
        
        let os = ProcessInfo().operatingSystemVersion
        return "IOS " + String(os.majorVersion) + "." + String(os.minorVersion) + "." + String(os.patchVersion)
    
    }
}
