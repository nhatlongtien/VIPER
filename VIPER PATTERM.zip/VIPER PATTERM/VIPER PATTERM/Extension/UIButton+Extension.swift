//
//  UIButton+Extension.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/22/22.
//

import Foundation
import UIKit
// Declare a global var to produce a unique address as the assoc object handle
var disabledColorHandle: UInt8 = 0
var normalColorHandle: UInt8 = 0
var buttonStyleHandle: UInt8 = 0
fileprivate enum BUTTON_STYLE: Int{
    case normal = -1
    case register = 1
    
    public init(){
        self = .normal
    }
    public init(value: Int){
        var result = BUTTON_STYLE()
        switch value {
        case BUTTON_STYLE.register.rawValue:
            result = BUTTON_STYLE.register
        default:
            result = BUTTON_STYLE.normal
        }
        self = result
    }
    
}
@IBDesignable extension UIButton {
    
    @IBInspectable
    var titleLocalizedKey: String? {
        get {
            return self.titleLocalizedKey
        }
        set {
            if let key = newValue {
                self.setTitle(key, for: UIControl.State.normal)
            }
        }
    }
    
    @IBInspectable
    var normalColor: UIColor?{
        get{
            if let color = objc_getAssociatedObject(self, &normalColorHandle) as? UIColor {
                return color
            }
            return self.backgroundColor
        }
        set{
            objc_setAssociatedObject(self, &normalColorHandle, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            
        }
    }
     @IBInspectable
    var disableColor: UIColor?{
        get{
            if let color = objc_getAssociatedObject(self, &disabledColorHandle) as? UIColor {
                return color
            }
            return self.backgroundColor
        }
        set{
            
            objc_setAssociatedObject(self, &disabledColorHandle, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            
        }
    }
    @IBInspectable
    var buttonStyle: Int{
        get{
            if let style = objc_getAssociatedObject(self, &buttonStyleHandle) as? Int {
                return style
            }
            return -1
        }
        set{
            objc_setAssociatedObject(self, &buttonStyleHandle, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
            if(isEnabled){
                let style = BUTTON_STYLE(value: self.buttonStyle)
                if(style == .register){
                    layer.shadowOpacity = 0.5
                    layer.shadowOffset = CGSize(width: 0, height: 3)
                    layer.shadowRadius = 5
                    self.backgroundColor = normalColor
                }
            }
            else{
                let style = BUTTON_STYLE(value: self.buttonStyle)
                if(style == .register){
                    layer.shadowOpacity = 0
                    layer.shadowOffset = CGSize(width: 0, height: 0)
                    layer.shadowRadius = 5
                    self.backgroundColor = disableColor
                }
            }
        }
    }
    
    /// Overriding the isEnabled property in the UIButton extension will not work from iOS 13 upto
    override open var isEnabled:Bool{
        didSet{
            let style = BUTTON_STYLE(value: self.buttonStyle)
            if(style == .normal){
                return
            }
            if(isEnabled){
                switch style {
                case .register:
                    layer.shadowOpacity = 0.5
                    layer.shadowOffset = CGSize(width: 0, height: 3)
                    layer.shadowRadius = 5
                    self.backgroundColor = normalColor
                    return
                default:
                    return
                }
            }
            else{
                switch style {
                case .register:
                    layer.shadowOpacity = 0
                    layer.shadowOffset = CGSize(width: 0, height: 0)
                    layer.shadowRadius = 5
                    self.backgroundColor = disableColor
                    return
                default:
                    return
                }
            }
        }
    }

    func setEnableButton(isEnable: Bool) {
        if isEnable {
            self.backgroundColor = UIColor(hexString: "B41E8E")
            self.isUserInteractionEnabled = true
        } else {
            self.backgroundColor = UIColor(hexString: "B59EAF")
            self.isUserInteractionEnabled = false
        }
    }

    func setEnableButtonWithTitle(isEnable: Bool, titleEnable: String, titleDisable: String, isUppercase: Bool = false) {
        if isEnable {
            if isUppercase {
                self.setTitle(titleEnable.capitalizingFirstLetter(), for: .normal)
            } else {
                self.setTitle(titleEnable, for: .normal)
            }
            self.backgroundColor = UIColor(hexString: "B41E8E")
            self.isUserInteractionEnabled = true
        } else {
            if isUppercase {
                self.setTitle(titleDisable.capitalizingFirstLetter(), for: .normal)
            } else {
                self.setTitle(titleDisable, for: .normal)
            }
            self.backgroundColor = UIColor(hexString: "B59EAF")
            self.isUserInteractionEnabled = false
        }
    }

}
