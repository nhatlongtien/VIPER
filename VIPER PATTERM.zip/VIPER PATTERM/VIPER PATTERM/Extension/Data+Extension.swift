//
//  Data+Extension.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/21/22.
//

import Foundation
extension Date {
    static var dateFormatter = DateFormatter()

    func convertString() -> String {
        Date.dateFormatter.dateFormat = "dd-MM-yyyy"
        Date.dateFormatter.locale = Locale(identifier: "vi_VN")

        return Date.dateFormatter.string(from: self)
    }
    
    static func convertDate(fromString:String,format:String = "yyyy-MM-dd",timeZoneIdentifier:String = "UTC") ->Date?{
        guard let timeZone = TimeZone(identifier: timeZoneIdentifier) else {
            return nil
        }
        Date.dateFormatter.locale = Locale(identifier: "vi_VN")
        Date.dateFormatter.dateFormat = format
        Date.dateFormatter.timeZone = timeZone
        return Date.dateFormatter.date(from: fromString) ?? nil
    }
    
    
    /// Returns a Date with the specified amount of components added to the one it is called with
    func add(years: Int = 0, months: Int = 0, days: Int = 0, hours: Int = 0, minutes: Int = 0, seconds: Int = 0) -> Date? {
        let components = DateComponents(year: years, month: months, day: days, hour: hours, minute: minutes, second: seconds)
        return Calendar.current.date(byAdding: components, to: self)
    }
    
    /// Returns a Date with the specified amount of components subtracted from the one it is called with
    func subtract(years: Int = 0, months: Int = 0, days: Int = 0, hours: Int = 0, minutes: Int = 0, seconds: Int = 0) -> Date? {
        return add(years: -years, months: -months, days: -days, hours: -hours, minutes: -minutes, seconds: -seconds)
    }
    
    func toString(format stringFormat: String,
                  locale: Locale = Locale(identifier: "vi_VN")) -> String {
        
        let dateFormat = DateFormatter.init()
        dateFormat.locale = locale
        dateFormat.dateFormat = stringFormat
        
        return dateFormat.string(from: self)
    }
    
    func toStringWithTimeZone(format stringFormat: String,
                              locale: Locale = Locale(identifier: "vi_VN"),
                              timeZoneIdentifier: String = "UTC") -> String {
        
        let timeZone = TimeZone(identifier: timeZoneIdentifier)
        
        let dateFormat = DateFormatter.init()
        dateFormat.locale = locale
        dateFormat.dateFormat = stringFormat
        dateFormat.timeZone = timeZone
        
        return dateFormat.string(from: self)
    }
    
    func current(option:Calendar.Component) ->Int{
       // let date = self
        let calendar = Calendar.current
        return calendar.component(option, from: self)
    }
    
    func next(option:Calendar.Component) ->Date?{
        return Calendar.current.date(byAdding: option, value: 1, to: self)
    }
    
    func next(option:Calendar.Component) ->Int{
        let date:Date? = self.next(option: option)
        return date?.current(option:option) ?? 0
    }
    
    func startDay()->Date?{
        let calendar = Calendar.current
        let startCurrentDate = calendar.startOfDay(for: self)
        let strDate = startCurrentDate.toString(format: "dd/MM/yyyy HH:mm:ss")
        let startDate = Date.convertDate(fromString: strDate, format: "dd/MM/yyyy HH:mm:ss")
        return startDate
    }
    
    func distanceTo(date: Date, component: Calendar.Component) -> Int? {
        let calendar = Calendar.current
        
        // Replace the hour (time) of both dates with 00:00
        let firstDate = calendar.startOfDay(for: self)
        let secondDate = calendar.startOfDay(for: date)
        
        let components = calendar.dateComponents([component], from: firstDate, to: secondDate)
        
        switch component {
        case .day:
            return components.day
        case .month:
            return components.month
        case .year:
            return components.year
        case .hour:
            return components.hour
        case .minute:
            return components.minute
        case .second:
            return components.second
        case .era:
            return components.era
        case .weekday:
            return components.weekday
        case .weekdayOrdinal:
            return components.weekdayOrdinal
        case .quarter:
            return components.quarter
        case .weekOfMonth:
            return components.weekOfMonth
        case .weekOfYear:
            return components.weekOfYear
        case .yearForWeekOfYear:
            return components.yearForWeekOfYear
        case .nanosecond:
            return components.nanosecond
        case .calendar:
            return nil
        case .timeZone:
            return nil
    }
    }
}

extension Date{
    
    static func convertInt64ToStringDate(miliseconds: Int64) -> String{
        let date = Date(timeIntervalSince1970: TimeInterval(miliseconds))
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        return dateFormatter.string(from: date)
    }

}
