//
//  UIAlertViewController+Extension.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/21/22.
//

import Foundation
import UIKit

private var associationKey: UInt8 = 0

extension UIAlertController{
    
    static func show(title:String = "Message",message:String,actionButtonTitle:[String] = ["OK"],handleComplete:@escaping ((_ buttonIndex:Int)->())){
        let topViewController = UIApplication.topViewController()
    
        
        let alert = self.init(title: title, message: message, preferredStyle: .alert)
        var i = 0
        for item in actionButtonTitle{
            let alertStyle = (i == 0) ? UIAlertAction.Style.default : UIAlertAction.Style.cancel
            
            let action = UIAlertAction(title: item, style: alertStyle) { (action) in
                handleComplete(i)
            }
             action.setValue(UIColor.applicationColor, forKey: "titleTextColor")
            alert.addAction(action)
            i = i + 1
        }
        
        topViewController?.present(alert, animated: true, completion: nil)
    }
    
    enum ActionButton {
        case basic(String)
        case cancel(String)
        case destructive(String)
        
        var style: UIAlertAction.Style {
            switch self {
            case .basic(_):
                return .default
            case .cancel(_):
                return .cancel
            case .destructive(_):
                return .destructive
            }
        }
        
        var title: String {
            switch self {
            case .basic(let text):
                return text
            case .cancel(let text):
                return text
            case .destructive(let text):
                return text
            }
        }
        
    }
    
    static func showAlert(title: String? = nil, message: String? = nil, actions: [ActionButton], isRegisterForm: Bool = false , handle: @escaping ((_ index: Int)->Void)) {
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        guard let topVC = UIApplication.topViewController() else { return }
       
        for i in 0..<actions.count {
            let action = actions[i]
            let actionButton = UIAlertAction.init(title: action.title, style: action.style) { (action) in
                handle(i)
            }
            actionButton.setValue(UIColor.applicationColor, forKey: "titleTextColor")
            alert.addAction(actionButton)
            
            if isRegisterForm, i == 1 {
                alert.preferredAction = actionButton
            }
        }
        
        topVC.present(alert, animated: true, completion: nil)
    }
    
    static func showActionSheet(title: String?, message: String?, sourceView: UIView?, actions: [ActionButton], handle:@escaping ((_ index: Int)->Void)) {
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .actionSheet)
        guard let topVC = UIApplication.topViewController() else { return }
        if let sourceView = sourceView {
            alert.popoverPresentationController?.sourceView = sourceView
            alert.popoverPresentationController?.sourceRect = sourceView.bounds
        } else {
            alert.popoverPresentationController?.sourceView = topVC.view
            alert.popoverPresentationController?.sourceRect = topVC.view.bounds
        }
        for i in 0..<actions.count {
            let action = actions[i]
            let actionButton = UIAlertAction.init(title: action.title, style: action.style) { (action) in
                handle(i)
            }
            alert.addAction(actionButton)
        }
        
        topVC.present(alert, animated: true, completion: nil)
    }
    
    
    // MARK: Global Alert
    
    private var alertWindow: UIWindow? {
        get {
            return objc_getAssociatedObject(self, &associationKey) as? UIWindow
        }
        
        set(newValue) {
            objc_setAssociatedObject(self, &associationKey, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN)
        }
    }
    
    func showGlobalAlert() {
        if #available(iOS 13.0, *) {
            self.alertWindow = UIWindow(frame: UIScreen.main.bounds)
            self.alertWindow?.backgroundColor = .clear
            
            let viewController = UIViewController()
            viewController.view.backgroundColor = .clear
            self.alertWindow?.rootViewController = viewController
            
            let topWindow = UIApplication.shared.windows.last
            if let topWindow = topWindow {
                self.alertWindow?.windowLevel = topWindow.windowLevel + 1
            }
            
            self.alertWindow?.makeKeyAndVisible()
            self.alertWindow?.rootViewController?.present(self, animated: true, completion: nil)
        } else {
            let alertWindow = UIWindow(frame: UIScreen.main.bounds)
            alertWindow.rootViewController = UIViewController()
            alertWindow.windowLevel = UIWindow.Level.alert + 1;
            alertWindow.makeKeyAndVisible()
            alertWindow.rootViewController?.present(self, animated: true, completion: nil)
        }
    }
    
    override open func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        if let alertWindow = alertWindow {
            alertWindow.isHidden = true
        }
        self.alertWindow = nil
    }
}
