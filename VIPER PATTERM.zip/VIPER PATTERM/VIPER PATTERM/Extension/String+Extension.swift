//
//  String+Extension.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/21/22.
//

import Foundation
import UIKit
extension String {
//    var localized: String {
//
//        guard let data = ApplicationLanguage.sharedInstance.currentLanguageData?.resourcesDic[self] as? String else {
//
//
//            let currentLan = ApplicationLanguage.sharedInstance.languageKey
//           guard let path = Bundle.main.path(forResource: currentLan,   ofType: "lproj"),
//                let bundle = Bundle(path: path)
//            else{
//                return ""
//            }
//            return NSLocalizedString(self, tableName: nil, bundle: bundle, value: "", comment: "").changeStringSwiftFormat
//
//        }
//        return data.changeStringSwiftFormat
//        //return Bundle.localizedBundle.localizedString(forKey: self, value: nil, table: nil)
//    }
    
    func width(withConstrainedHeight height: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [.font : font], context: nil)
        
        return ceil(boundingBox.width)
    }

    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [.font : font], context: nil)

        return ceil(boundingBox.height)
    }
    
    func widthOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedString.Key.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.width
    }

    func heightOfString(usingFont font: UIFont) -> CGFloat {
        let fontAttributes = [NSAttributedString.Key.font: font]
        let size = self.size(withAttributes: fontAttributes)
        return size.height
    }

    func sizeOfString(usingFont font: UIFont) -> CGSize {
        let fontAttributes = [NSAttributedString.Key.font: font]
        return self.size(withAttributes: fontAttributes)
    }
    
    func append(params: [String: Any]) -> String? {
        var components = URLComponents(string: self)
        components?.queryItems = params.map { element in URLQueryItem(name: element.key, value: String(describing:element.value)) }
        
        return components?.url?.absoluteString
    }
    
    func openURL(){
        if let url = URL(string: self){
            if UIApplication.shared.canOpenURL(url) {
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                } else {
                    // Fallback on earlier versions
                    UIApplication.shared.openURL(url)
                }

            }
        }
    }
    

    var changeStringSwiftFormat:String{
        return self.replacingOccurrences(of: "%s", with: "%@").replacingOccurrences(of: "%d", with: "%@")
            .replacingOccurrences(of: "\\r", with: "\r")
            .replacingOccurrences(of: "\\n", with: "\n")
    }
    
    func dateString(from sourceDateFormat: String, to destinationDateFormat: String) -> String? {
        return self.toDate(format: sourceDateFormat)?.toString(format: destinationDateFormat)
    }
    
    func toDate(format stringFormat: String,
                locale: Locale = Locale(identifier: "vi_VN")) -> Date? {
        
        let dateFormat = DateFormatter.init()
        dateFormat.locale = locale
        dateFormat.dateFormat = stringFormat
        
        return dateFormat.date(from: self)
    }
    
    func toDateWithTimeZone(format stringFormat: String,
                            locale: Locale = Locale(identifier: "vi_VN"),
                            timeZoneIdentifier: String = "UTC") -> Date? {
        
        let timeZone = TimeZone(identifier: timeZoneIdentifier)
        
        let dateFormat = DateFormatter.init()
        dateFormat.locale = locale
        dateFormat.dateFormat = stringFormat
        dateFormat.timeZone = timeZone
        
        return dateFormat.date(from: self)
    }
    
    func parseDateStringWithFormat(inputFormat:String = "yyyy-MM-dd'T'HH:mm:ss.SSS",
                                   outputFormat:String,
                                   timeZoneIdentifier:String = "UTC",
                                   locale:Locale = Locale(identifier: "vi_VN")) -> String {
       
            guard let timeZone = TimeZone(identifier: timeZoneIdentifier) else {
                return ""
            }

            let dateFormatter = DateFormatter()
            dateFormatter.locale = locale
            dateFormatter.dateFormat = inputFormat
            dateFormatter.timeZone = timeZone

            guard let date = dateFormatter.date(from: self) else {
                return ""
            }
        
        
            dateFormatter.dateFormat = outputFormat
            dateFormatter.timeZone = timeZone
            let timeStamp = dateFormatter.string(from: date)
            
            return timeStamp
    }

    func parseTimeString(timeZoneIdentifier:String = "UTC") -> Date? {
         guard let timeZone = TimeZone(identifier: timeZoneIdentifier) else {
             return nil
         }

         let dateFormatter = DateFormatter()
         dateFormatter.locale = Locale(identifier: "vi_VN")
         dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
         dateFormatter.timeZone = timeZone

         return dateFormatter.date(from: self)
     }

    /// Validate Email
    ///
    /// - Returns: true/false
    func validateEmail()->Bool{
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self)
    }
    
    /// Validate Password
    ///Minimum eight characters, at least one uppercase letter, one lowercase letter and one number
    ///"^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$"
    ///Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character
    ///"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
    /// - Returns: true/false
    func validatePassword()->Bool{
        let passwordRegEx = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$"
        let passwordTest = NSPredicate(format:"SELF MATCHES %@", passwordRegEx)
        return passwordTest.evaluate(with:self)

    }
    
    subscript (bounds: CountableClosedRange<Int>) -> String {
        let start = index(startIndex, offsetBy: bounds.lowerBound)
        let end = index(startIndex, offsetBy: bounds.upperBound)
        return String(self[start...end])
    }
    
    subscript (bounds: CountableRange<Int>) -> String {
        let start = index(startIndex, offsetBy: bounds.lowerBound)
        let end = index(startIndex, offsetBy: bounds.upperBound)
        return String(self[start..<end])
    }
    
    
    var htmlToAttributedString: NSAttributedString? {
        let html = "<div style='font-family: NunitoSans-Regular;'>\(self)</div>"
        return html.htmlToNewAttributedString
    }

    var htmlToNewAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return NSAttributedString() }
       do {
           return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, NSAttributedString.DocumentReadingOptionKey("CharacterEncoding"):String.Encoding.utf8.rawValue], documentAttributes: nil)
       } catch {
           return NSAttributedString()
       }
    }
    
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }

    func htmlToAttributedString(fontName: String, fontSize: Int, textColor: String) -> NSAttributedString? {
        let html = "<div style='font-family: \(fontName); font-size: \(fontSize)px; color: #\(textColor);'>\(self)</div>"
        return html.htmlToNewAttributedString
    }
    
    func checkWhiteSpace() -> Bool {
        if isEmpty {
            return true
        }
        return trimmingCharacters(in: .whitespaces) == ""
    }
    
    func generateBarcode() -> UIImage? {
        let data = self.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CICode128BarcodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }
        
        return nil
    }
    
    func XoaDauTiengViet()->String{
        var str = self;
        str = str.replacingOccurrences(of: "đ", with: "D");
        str = str.replacingOccurrences(of: "Đ", with: "D");
        let data = str.data(using: .ascii, allowLossyConversion: true);
        let strOut =  String(data: data!, encoding: String.Encoding.ascii);
        return strOut!;
    }
    
    static func ==(lhs: String, rhs: String) -> Bool {
        return lhs.compare(rhs, options: .numeric) == .orderedSame
    }
    
    static func <(lhs: String, rhs: String) -> Bool {
        return lhs.compare(rhs, options: .numeric) == .orderedAscending
    }
    
    static func <=(lhs: String, rhs: String) -> Bool {
        return lhs.compare(rhs, options: .numeric) == .orderedAscending || lhs.compare(rhs, options: .numeric) == .orderedSame
    }
    
    static func >(lhs: String, rhs: String) -> Bool {
        return lhs.compare(rhs, options: .numeric) == .orderedDescending
    }
    
    static func >=(lhs: String, rhs: String) -> Bool {
        return lhs.compare(rhs, options: .numeric) == .orderedDescending || lhs.compare(rhs, options: .numeric) == .orderedSame
    }
    
    var boolValue:Bool{
        
        return NSString(string: self).boolValue
    }
    func phoneNumberWithoutRegionCode() -> String{
        var phoneNumber = self
        let index2 = self.index(self.startIndex, offsetBy: 2)
        if self[...index2] == "+84" {
            let index3 = self.index(self.startIndex, offsetBy: 3)
            phoneNumber = "0" + self[index3...]
        }
        return phoneNumber
    }
}

// Extension for validate phone number and Make a phone call from string
extension String {
    
    enum RegularExpressions: String {
        case phone = "^\\s*(?:\\+?(\\d{1,3}))?([-. (]*(\\d{3})[-. )]*)?((\\d{3})[-. ]*(\\d{2,4})(?:[-.x ]*(\\d+))?)\\s*$"
    }
    
    func isValid(regex: RegularExpressions) -> Bool {
        return isValid(regex: regex.rawValue)
    }
    
    func isValid(regex: String) -> Bool {
        let matches = range(of: regex, options: .regularExpression)
        return matches != nil
    }
    
    func onlyDigits() -> String {
        let filtredUnicodeScalars = unicodeScalars.filter{CharacterSet.decimalDigits.contains($0)}
        return String(String.UnicodeScalarView(filtredUnicodeScalars))
    }
    
    func makeACall() {
        if isValid(regex: .phone) {
            if let url = URL(string: "tel://\(self.onlyDigits())"), UIApplication.shared.canOpenURL(url) {
                if #available(iOS 10, *) {
                    UIApplication.shared.open(url)
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        }
    }
    
    func makeACallWithoutValid() {
        if let url = URL(string: "tel://\(self.onlyDigits())"), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
}

extension String  {
    var isNumber: Bool {
        return !isEmpty && rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil
    }
}

extension String{
    var VNDCurency:String{
        var number = NSNumber()
        if let interger = Int(self){
            number = NSNumber(integerLiteral: interger)
        }
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        numberFormatter.number(from: self)
        
        if let value = numberFormatter.string(from: number)?.replacingOccurrences(of: ",", with: "."){
            return value + "đ"
        }
        return self + "đ"
    }
    
    var Curency:String{
        var number = NSNumber()
        if let interger = Int(self){
            number = NSNumber(integerLiteral: interger)
        }
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        numberFormatter.number(from: self)
        
        if let value = numberFormatter.string(from: number)?.replacingOccurrences(of: ",", with: "."){
            return value
        }
        return self
    }
    
    var decimalPoint:String{
        var number = NSNumber()
        if let interger = Int(self){
            number = NSNumber(integerLiteral: interger)
        }
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        numberFormatter.number(from: self)
        
        if let value = numberFormatter.string(from: number)?.replacingOccurrences(of: ",", with: "."){
            return value
        }
        return self
    }
}

extension String{
    func toAttributeString() -> NSMutableAttributedString{
        let att = NSMutableAttributedString(string: self, attributes: nil)
        return att
    }
}

extension String {

    init?(htmlEncodedString: String) {

        guard let data = htmlEncodedString.data(using: .utf8) else {
            return nil
        }

        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.html,
            .characterEncoding: String.Encoding.utf8.rawValue
        ]

        guard let attributedString = try? NSAttributedString(data: data, options: options, documentAttributes: nil) else {
            return nil
        }

        self.init(attributedString.string)

    }

}

extension String {
    func capitalizingFirstLetter() -> String {
        return prefix(1).capitalized + dropFirst()
    }

    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
}

extension UITextField{
    
}
