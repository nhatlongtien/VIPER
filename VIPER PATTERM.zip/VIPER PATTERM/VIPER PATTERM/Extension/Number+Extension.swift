//
//  Number+Extension.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/21/22.
//

import Foundation
import UIKit

extension NSNumber{
    var VNDCurency:String{
        
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        numberFormatter.string(from: self)
        if let value = numberFormatter.string(from: self)?.replacingOccurrences(of: ",", with: "."){
            return value + "đ"
        }
        return "0đ"
    }

    var vnd: String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        numberFormatter.string(from: self)
        if let value = numberFormatter.string(from: self)?.replacingOccurrences(of: ",", with: "."){
            return value
        }
        return "0"
    }

    func removeZero() -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        return formatter.string(from: self) ?? ""
    }
}
