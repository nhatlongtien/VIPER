//
//  URL+Extension.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
extension URL{
    
    /// SwifterSwift: URL with appending query parameters.
    ///
    ///        let url = URL(string: "https://google.com")!
    ///        let param = ["q": "Swifter Swift"]
    ///        url.appendingQueryParameters(params) -> "https://google.com?q=Swifter%20Swift"
    ///
    /// - Parameter parameters: parameters dictionary.
    /// - Returns: URL with appending given query parameters.
    public func appendingQueryParameters(_ parameters: [String: Any]) -> URL {
        var urlComponents = URLComponents(url: self, resolvingAgainstBaseURL: true)!
        
        
        var cs = CharacterSet.urlQueryAllowed
        cs.remove("+")
        
        // Sort url parameter to make sure url matching with url in local cache
        let sortedPamameter = parameters.sorted { (left, right) -> Bool in
            return left.key < right.key
        }
        
        urlComponents.percentEncodedQuery = sortedPamameter.map {
            $0.addingPercentEncoding(withAllowedCharacters: cs)! +
                "=" +
                String(describing: $1).addingPercentEncoding(withAllowedCharacters: cs)!
        }.joined(separator:"&")
        
        return urlComponents.url!
    }
    
    /// SwifterSwift: Append query parameters to URL.
    ///
    ///        var url = URL(string: "https://google.com")!
    ///        let param = ["q": "Swifter Swift"]
    ///        url.appendQueryParameters(params)
    ///        print(url) // prints "https://google.com?q=Swifter%20Swift"
    ///
    /// - Parameter parameters: parameters dictionary.
    public mutating func appendQueryParameters(_ parameters: [String: Any]) {
        self = appendingQueryParameters(parameters)
    }
}
