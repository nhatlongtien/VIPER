//
//  APISessionManager.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import Alamofire

class APISessionManager {
    
    static let shared = APISessionManager()
    
    let manager: Alamofire.SessionManager = {
        let configuration = URLSessionConfiguration.default
        configuration.requestCachePolicy = .useProtocolCachePolicy
        configuration.timeoutIntervalForRequest = 120
        configuration.timeoutIntervalForResource = 120
        configuration.urlCache = URLCache.shared
        return Alamofire.SessionManager(configuration: configuration)
    }()
    
    init() {
        let delegateSession: Alamofire.SessionDelegate = manager.delegate
        delegateSession.dataTaskWillCacheResponse = { (session, task, cache) in
            if let cachePolicy = task.currentRequest?.cachePolicy {
                if cachePolicy == .useProtocolCachePolicy || cachePolicy == .reloadIgnoringCacheData {
                    if let maxAgeStr = task.currentRequest?.allHTTPHeaderFields?["time-age"] {
                        guard let maxAge = TimeInterval.init(maxAgeStr) else {
                            return cache
                        }
                        return cache.transformCache(maxAge: maxAge)
                    }
                }
                return nil
            } else {
                return nil
            }
        }
    }
    
    fileprivate var cache = URLCache.shared
    
}

extension CachedURLResponse {
    func transformCache(maxAge: TimeInterval) -> CachedURLResponse {
        if let response = self.response as? HTTPURLResponse {
            var headers = response.allHeaderFields as! [String: String]
            headers["Cache-Control"] = "max-age=\(maxAge), public"
            headers.removeValue(forKey: "Expires")
            headers.removeValue(forKey: "Pragma")
            let modifiedResponse = HTTPURLResponse(
                url: response.url!,
                statusCode: response.statusCode,
                httpVersion: "HTTP/1.1",
                headerFields: headers)
            
            let modifiedCachedResponse = CachedURLResponse(
                response: modifiedResponse!,
                data: self.data,
                userInfo: self.userInfo,
                storagePolicy: self.storagePolicy)
            return modifiedCachedResponse
        }
        return self
    }
}
