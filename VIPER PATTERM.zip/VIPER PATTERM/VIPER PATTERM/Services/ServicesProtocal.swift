//
//  ServicesProtocal.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import PromiseKit
import Alamofire
protocol ServicesProtocal {
    
    
    /// Return method of the request when executed in a specific service
    ///
    /// - Returns: [String:Any]
    func method() ->HTTPMethod
    
    /// Return header of the request when executed in a specific service
    ///
    /// - Returns: [String:Any]
    func headers() -> [String :String]
    
    /// Return environment of the request when executed in a specific service
    ///
    /// - Returns: String
    func environment() ->Environment
    
    
    /// Return the end point url of the request
    ///
    /// - Returns: String
    func endPoint() -> String
    
    
    /// Return the full url of the request when executed in a specific service. It   combine environment and endpoint
    ///
    /// - Returns: URLConvertible
    func url() throws -> URLConvertible
    
    /// Return an cache policy for URLRequest
    ///
    /// - Returns: URLRequest.CachePolicy
    
    func cachePolicy() -> URLRequest.CachePolicy?
    
    /// Create an URLRequest from a Request into the current service.
    ///
    /// - Returns: RequestConverter
    /// - Throws: throw an exception if something goes wrong while making data
    func urlRequest(bodyParameters:Parameters, urlParameters:Parameters) throws -> RequestConverter
}
