//
//  DemoAPI.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import UIKit
import Alamofire
import PromiseKit

class DemoAPI:BaseAPIServices{
    
    
    override func method() -> HTTPMethod {
        return .post
    }
    
    override func endPoint() -> String {
        return "auth/checkpassword"
    }
    
    func checkPasword(password:String) -> Promise<DemoAPIModel>{
        let parameter = ["password":password] as [String : Any]
        return self.executeRequest(bodyParameters: parameter)
    }
    
}
