//
//  APIServicesFactory.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
class APIServicesFactory: NSObject {
    static let demoAPI = DemoAPI()
    
}

class MapServiceFactory {
    
}
