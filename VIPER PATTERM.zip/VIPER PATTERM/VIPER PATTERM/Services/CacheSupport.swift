//
//  CacheSupport.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
enum CacheSupport {
    case noCache
    case expires(in: ExpiresType)
    case alwayUseCacheIfCan
    
    var cachePolicy: URLRequest.CachePolicy {
        switch self {
        case .noCache:
            return .reloadIgnoringCacheData
        case .expires(in: _):
            return .useProtocolCachePolicy
        case .alwayUseCacheIfCan:
            return .returnCacheDataElseLoad
        }
    }
}

enum ExpiresType {
    case day(Float)
    case hour(Float)
    case second(TimeInterval)
    case date(Date)
    
    var time: TimeInterval {
        switch self {
        case .day(let day):
            return Double(day * 24.0 * 60.0 * 60.0)
        case .hour(let hour):
            return Double(hour * 60.0 * 60.0)
        case .second(let second):
            return second
        case .date(let expiresDate):
            let current = Date.init().timeIntervalSince1970
            let expiresTimestamp = expiresDate.timeIntervalSince1970
            let distanceTime = expiresTimestamp - current
            if distanceTime < 0 {
                return 0.0
            } else {
                return distanceTime
            }
        }
    }
    
}

