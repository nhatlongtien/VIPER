//
//  ReadFileService.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
class ReadFileService{
    static let shared = ReadFileService()
    
    /// Read Data From File
    ///
    /// - Parameters:
    ///   - fileName: File Name
    ///   - type: Format Of File
    /// - Returns: Data?
    func readDataFromFile(fileName: String, type:String)->Data?{
        let path = Bundle.main.path(forResource: fileName, ofType: type)
        do{
            let dataFile = try Data(contentsOf: URL(fileURLWithPath: path!))
            return dataFile
        }catch{
            print("Error Read data from file \(fileName): \(error.localizedDescription)")
            return nil
        }
    }
    
    /// Convert Data To Object
    ///
    /// - Parameter data: Data from file
    /// - Returns: Object implement Codability
    func fileDataToObject<T>(data:Data)->T where T:Codability{
        return T.decode(data: data)!
    }
    
    /// Convert Data To Array Object
    ///
    /// - Parameter data: Data From file
    /// - Returns: Array Objects implement Codability
    func fileDataToObjects<T>(data:Data)->[T] where T:Codability{
        let arrJson = try? JSONSerialization.jsonObject(with: data, options: []) as! NSArray
        var arrayT = [T]();
        for json in arrJson! {
            let obj = T.decode(json: json as! [String : Any])
            arrayT.append(obj!)
        }
        return arrayT
    }
}
