//
//  RequestConverter.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import Alamofire
/// Protocol that conforms to URLRequestConvertible to all Alamofire integration
protocol RequestConverterProtocol: URLRequestConvertible {
    var method: HTTPMethod {get set}
    var route: String {get set}
    var bodyParameters: Parameters {get set}
    var urlParameters: Parameters {get set}
    var environment: Environment {get set}
    var headers:[String:String] {get set}
    var cachePolicy: URLRequest.CachePolicy? {get set}
}

/// Converter object that will allow us to play nicely with Alamofire
struct RequestConverter: RequestConverterProtocol {
    
    var method: HTTPMethod
    var route: String
    var bodyParameters: Parameters = [:]
    var urlParameters: Parameters = [:]
    var environment: Environment
    var headers: [String:String] = [:]
    var cachePolicy: URLRequest.CachePolicy?
    /// Create a RequestConverter object
    ///
    /// - Parameters:
    ///   - method: Method to perform on router. Example: `.get`, `.post`, etc.
    ///   - route: Route endpoint on url.
    ///   - parameters: Optional dictionary to pass in objects. Used for `.post` and `.put`
    init(method: HTTPMethod,environment:Environment,
         route: String, bodyParameters: Parameters = [:],
         urlParameters:Parameters = [:] ) {
        self.method = method
        self.route = route
        self.bodyParameters = bodyParameters
        self.urlParameters = urlParameters
        self.environment = environment
    }
    
    init(method: HTTPMethod, route: String,environment:Environment,
         headers:[String:String], bodyParameters: Parameters = [:],
         urlParameters:Parameters = [:],cachePolicy:URLRequest.CachePolicy?){
        
        self.method = method
        self.route = route
        self.environment = environment
        self.bodyParameters = bodyParameters
        self.urlParameters = urlParameters
        self.headers = headers
        self.cachePolicy = cachePolicy
        
    }
    /// Required method to conform to the `URLRequestConvertible` protocol.
    ///
    /// - Returns: URLRequest object
    /// - Throws: An `Error` if the underlying `URLRequest` is `nil`.
    func asURLRequest() throws -> URLRequest {
        
        let strUrl = environment.rawValue + "/" + route
       
        //url Parameters
        
         var url = try strUrl.asURL()
        
        if(urlParameters.count > 0){
            //strUrl = strUrl.append(params: urlParameters) ?? strUrl
            url.appendQueryParameters(urlParameters)
        }
       
        var urlRequest = URLRequest(url: url)
        //Get Access Token
        var tHeader = headers
//        if let loginData = Defaults.getObject(forKey: .loginInfo){
//            let loginInfo = LoginInfo.decode(data: loginData)
//            let token = loginInfo?.accessToken
//            tHeader["Authorization"] = String(format: "BEARER %@", token ?? "")
//        }
        tHeader["User-Agent"] = generateUserAgent()
        // HTTP Method
        urlRequest.httpMethod = method.rawValue
        urlRequest.allHTTPHeaderFields = tHeader

        if(cachePolicy != nil ){
            urlRequest.cachePolicy = cachePolicy!
        }
        
        // Body Parameters
        if(bodyParameters.count > 0 )
        {
            do {
                urlRequest.httpBody = try JSONSerialization.data(withJSONObject: bodyParameters, options: [])
            } catch {
                throw AFError.parameterEncodingFailed(reason: .jsonEncodingFailed(error: error))
            }
        }
        return urlRequest
    }
    
    func generateUserAgent() ->String{
        let bundleID = Bundle.main.bundleIdentifier ?? "unknow"
        let version = Bundle.main.releaseVersionNumber
        //let os = Bundle.main.osVersion
        
          #if DEBUG
        return String(format: "%@/%@/%@/%@", bundleID,version,"IOS","TEST")
         #else
        return String(format: "%@/%@/%@/%@", bundleID,version,"IOS","RELEASE")
        #endif
    }
}
