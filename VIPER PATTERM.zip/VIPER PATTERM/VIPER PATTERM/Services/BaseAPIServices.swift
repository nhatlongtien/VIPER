//
//  BaseAPIServices.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import UIKit
import Alamofire
import PromiseKit


protocol IntType {}
extension Int:IntType{}

class BaseAPIServices: ServicesProtocal {
    
    func method() -> HTTPMethod {
        return .get
    }
    func headers() -> [String : String] {
        //        let headers = ["Content-Type":"application/json",
        //                       "Accept":"application/json",
        //                       "x-api-key":HTTPHeaderField.azureAuthentication.rawValue]
        //        return headers
        var header = environment().header
        switch cacheType() {
        case .expires(in: let expires):
            header["time-age"] = "\(expires.time)"
            break
        default:
            break
        }
        return header
    }
    
    func environment() -> Environment {
        return .BASE_ENVIRONMENT
    }
    
    func endPoint() -> String {
        fatalError("Must Override end point")
    }
    
    func cacheType() -> CacheSupport {
        return .noCache
    }
    
    final func cachePolicy() -> URLRequest.CachePolicy?{
        switch cacheType() {
        case .alwayUseCacheIfCan:
            return URLRequest.CachePolicy.returnCacheDataElseLoad
        case .noCache:
            return URLRequest.CachePolicy.reloadIgnoringCacheData
        case .expires(in: _):
            return URLRequest.CachePolicy.useProtocolCachePolicy
        }
    }
    func url() throws -> URLConvertible {
        return try String(format: "%@/%@", environment().rawValue,endPoint()).asURL()
    }
    
    func urlRequest(bodyParameters:Parameters, urlParameters:Parameters) throws -> RequestConverter {
        
        return RequestConverter(method: method(),// phuong thức get
                                route: endPoint(),// product ID
                                environment: environment(),// domain
                                headers: headers(),// là header
                                bodyParameters:bodyParameters,
                                urlParameters:urlParameters,// key api
                                cachePolicy: cachePolicy())// ko bik
    }
   
    func APILog(_ STATUS: String, _ MSG: String?) {
        print(">>> [API] [\( environment().rawValue )] [\( method().rawValue )] [\( endPoint() )] \( STATUS )")
        if let msg = MSG { print("\( msg )\n\n") }
    }
    
    func executeRequest<T>(bodyParameters:Parameters = [:],
                           urlParameters:Parameters = [:], forceReload: Bool = false) -> Promise<T> where T:Codability{
        
        
        var router = try? self.urlRequest(bodyParameters: bodyParameters, urlParameters: urlParameters)
        
        if forceReload {
            router?.cachePolicy = URLRequest.CachePolicy.reloadIgnoringCacheData
        }
        
        /// API Log
        APILog("REQUEST-\(endPoint())", (bodyParameters.count > 0) ? "\(bodyParameters.description)" : "\(urlParameters.description)")
        
       // Alamofire.request(router!).responseDecodable()
        return Promise { promiseHandler in

                    APISessionManager.shared.manager.request(router!)
                        .responseJSON(completionHandler: { (response) in
                            
                            /// API Log
                            if let dataResponse = response.data  {
                                let logResult = String(data: dataResponse, encoding: .utf8)
                                var logStatus: String

                                if let statusCode = response.response?.statusCode {
                                    logStatus = String(statusCode)
                                }else if let error = response.error {
                                    logStatus = "\(error)"
                                }else{
                                    logStatus = "Unexpected Error!"
                                }
                                self.APILog("RESPONSE-\(logStatus)", logResult)
                            }
                            
                            /// Handle response
                            let (json,error) = self.responseErrorHandler(response: response)
                            if json == nil && error == nil {
                                
                            } else {
                                if let jsonDatas = json as? [[String:Any]]{
                                    
                                    for jsonData in jsonDatas{
                                        guard let data = T.decode(json:jsonData)else{
                                            return promiseHandler.reject(CustomError(code: 200, messageContent: "Đã có lỗi xảy ra trong quá trình thao tác dữ liệu từ máy chủ."))
                                            
                                           
                                        }

                                        promiseHandler.fulfill(data)
                                    }
          
                                }else if let jsonData = json as? [String: Any]{
                                   
                                    guard let data = T.decode(json:jsonData)else{
                                        return promiseHandler.reject(CustomError(code: 200, messageContent: "Đã có lỗi xảy ra trong quá trình thao tác dữ liệu từ máy chủ."))
                                    }

                                    promiseHandler.fulfill(data)
                                }  else{
                                    if(error == nil){
                                        return promiseHandler.reject(CustomError(code: 200, messageContent: "Đã có lỗi xảy ra trong quá trình thao tác dữ liệu từ máy chủ."))
                                    }
                                    else{
                                        promiseHandler.reject(error!)
                                    }
                                }
                            }
                        })
                }
    }
     
    func executeRequest<T>(bodyParameters:Parameters = [:],
                           urlParameters:Parameters = [:], forceReload: Bool = false) -> Promise<[T]> where T:Codability{
        
        
        var router = try? self.urlRequest(bodyParameters: bodyParameters, urlParameters: urlParameters)
        
        if forceReload {
            router?.cachePolicy = URLRequest.CachePolicy.reloadIgnoringCacheData
            //            APIService.shared.cache.removeCachedResponse(for: router!.urlRequest!)
        }
        
        /// API Log
        APILog("REQUEST-\(endPoint())", (bodyParameters.count > 0) ? "\(bodyParameters.description)" : "\(urlParameters.description)")
        
        return Promise { promiseHandler in
            APISessionManager.shared.manager.request(router!)
                .responseJSON(completionHandler: { (response) in
                   
                    /// API Log
                    if let dataResponse = response.data  {
                        let logResult = String(data: dataResponse, encoding: .utf8)
                        var logStatus: String

                        if let statusCode = response.response?.statusCode {
                            logStatus = String(statusCode)
                        }else if let error = response.error {
                            logStatus = "\(error)"
                        }else{
                            logStatus = "Unexpected Error!"
                        }
                        self.APILog("RESPONSE-\(logStatus)", logResult)
                    }
                    
                    /// Handle response
                    let (json,error) = self.responseErrorHandler(response: response)
                    if let jsonData = json as? Array<Any>{
                        var arrData = [T]()
                        for item in jsonData{
                            guard let itemJson = item as? [String :Any] else{
                                break
                            }
                            
                            guard let data = T.decode(json:itemJson)else{
                                return promiseHandler.reject(CustomError(code: 200, messageContent: "Đã có lỗi xảy ra trong quá trình thao tác dữ liệu từ máy chủ."))
                            }
                            arrData.append(data)
                            
                        }
                        
                        promiseHandler.fulfill(arrData)
                    }
                    else{
                        if let error = error{
                            promiseHandler.reject(error)
                        }else{
                            
                        }
                    }
                    
                })
        }
    }
    
    
    func executeRequest(bodyParameters:Parameters = [:],
                        urlParameters:Parameters = [:], forceReload: Bool = false) -> Promise<Any> {
        var router = try? self.urlRequest(bodyParameters: bodyParameters, urlParameters: urlParameters)
        
        if forceReload {
            router?.cachePolicy = URLRequest.CachePolicy.reloadIgnoringCacheData
        }
        
        /// API Log
        APILog("REQUEST-\(endPoint())", (bodyParameters.count > 0) ? "\(bodyParameters.description)" : "\(urlParameters.description)")
        
        return Promise { promiseHandler in
            APISessionManager.shared.manager.request(router!)
                .responseJSON(completionHandler: { (response) in
                    
                    /// API Log
                    if let dataResponse = response.data  {
                        let logResult = String(data: dataResponse, encoding: .utf8)
                        var logStatus: String

                        if let statusCode = response.response?.statusCode {
                            logStatus = String(statusCode)
                        }else if let error = response.error {
                            logStatus = "\(error)"
                        }else{
                            logStatus = "Unexpected Error!"
                        }
                        self.APILog("RESPONSE-\(logStatus)", logResult)
                    }
                    
                    /// Handle response
                    let (json,error) = self.responseErrorHandler(response: response)
                    if(error == nil){
                        promiseHandler.fulfill(json ?? [])
                    }
                    else{
                        promiseHandler.reject(error!)
                    }
                    
                })
        }
    }
    
    func responseErrorHandler(response:DataResponse<Any>) -> (json:Any?,error:Error?){
        let responseStatus = response.response?.statusCode ?? -1
        
        if responseStatus != 406{
            switch response.result {
            case .success(let json):
                
                if(responseStatus == 200){
                    return (json,nil)
                }
                else{
                    guard let json = json as? [String:Any] else{
                        return (nil,CustomError(code: responseStatus, messageContent: "Đã có lỗi xảy ra trong quá trình thao tác dữ liệu từ máy chủ."))
                    }
                    
                    var errorMessage = json["msg"] ?? "Unknown error please try again!"
                    if errorMessage is NSNull {
                        errorMessage = "Unknown error please try again!"
                    }
                    let error = CustomError(code: responseStatus, messageContent: errorMessage as! String)
                    if(responseStatus == 401){
                        //unauthorization
                        //Token het han
                    }
                    return (nil,error)
                }
                
            case .failure(let error):
                if(responseStatus == 401){
                    //unauthorization
                    //Token het han
                    
                }
                else{
                    //when get api error check cache and retrurn if exist cache
                    guard let request = response.request else{
                        return (nil,error)
                    }
                    guard let urlCache =  APISessionManager.shared.manager.session.configuration.urlCache else{
                        return (nil,error)
                    }
                    
                    guard let cacheResponse = urlCache.cachedResponse(for: request) else{
                        return (nil,error)
                    }
                    do{
                        
                        //here dataResponse received from a network request
                        let jsonResponse = try JSONSerialization.jsonObject(with: cacheResponse.data, options: [])
                        return (jsonResponse,nil)
                        
                    } catch _ {
                        return (nil,error)
                    }
                }
                return (nil,error)
            }
        } else {
            //return(nil,nil)
            switch response.result {
            case .success(let json):
                return (json,nil)
            case .failure(let error):
                return (nil, error)
            }
        }
    }
}
