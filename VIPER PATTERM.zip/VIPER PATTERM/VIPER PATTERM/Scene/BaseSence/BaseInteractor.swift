//
//  BaseInteractor.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/21/22.
//

import Foundation
import UIKit
class BaseInteractor: BaseControlLogic {
 
}
