//
//  BaseRouter.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import UIKit
import SafariServices

protocol Navigator {
    associatedtype Destination
    func push(to destination: Destination)
}

protocol SceneProtocol {
    //MARK: List Scene In App
    
}

class BaseRouter: BaseControlLogic,SceneProtocol {

    enum Destination {
        case goToScreen2(strData:String)
    }
    
    //MARK: Pop to Previous View Controller
    func pop(animate:Bool = true){
        navigationController?.popViewController(animated: animate)
    }
    
    //MARK: Push to Other View Controller
    func push(to destination: BaseRouter.Destination) {
        guard let viewController = self.destinationViewController(for: destination) else{
            return
        }
        navigationController?.pushViewController(viewController, animated: true)
    }
    
    //MARK: Present to Other View Controller
    func present(to destination: BaseRouter.Destination){
        guard let viewController = self.destinationViewController(for: destination) else{
            return
        }
        if let viewcontroller = self.handleController as? UIViewController{
            viewController.modalPresentationStyle = .fullScreen
            viewcontroller.present(viewController, animated: true)
        }
        else if let viewcontroller = self.handleController as? UITableViewController{
            viewController.modalPresentationStyle = .fullScreen
            viewcontroller.present(viewController, animated: true)
        }
    }
    
    //MARK: Dismiss View Controller
    func dismiss(animate:Bool = true){
        //        navigationController?.dismiss(animated: animate, completion: nil)
        if let viewcontroller = self.handleController as? UIViewController{
            viewcontroller.dismiss(animated: animate, completion: nil)        }
        else if let viewcontroller = self.handleController as? UITableViewController{
            viewcontroller.dismiss(animated: true, completion: nil)
        }else{
            navigationController?.dismiss(animated: animate, completion: nil)
        }
    }
    
    //MARK: Get View Controller From Destination
    func destinationViewController(for destination: BaseRouter.Destination) -> UIViewController?{
        // fatalError("Must Override to know destination View Controller")
        switch destination {
        case .goToScreen2(let strData):
            return gotoScreen2(strData: strData)
        default:
            fatalError("Must Override to know destination View Controller")
        }
    }
    func gotoScreen2(strData:String) -> ScreenTwoViewController{
        let targetVC = ScreenTwoViewController()
        return targetVC
    }
}
