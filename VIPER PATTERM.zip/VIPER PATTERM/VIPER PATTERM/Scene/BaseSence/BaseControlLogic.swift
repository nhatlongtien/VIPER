//
//  BaseControlLogic.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import UIKit

class BaseControlLogic: NSObject {
    
    var handleController:Any?
    var navigationController: UINavigationController?
    init(handleController: UIViewController?) {
        super.init()
        self.handleController = handleController;
        self.navigationController = handleController?.navigationController
        
    }
    init(handleController:UITableViewController?) {
        super.init()
        self.handleController = handleController;
        self.navigationController = handleController?.navigationController
    }
    init(handleController:UIView?) {
        super.init()
        self.handleController = handleController;
    }

}
