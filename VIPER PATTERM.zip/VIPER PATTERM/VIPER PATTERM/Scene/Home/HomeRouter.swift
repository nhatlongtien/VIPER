//
//  HomeRouter.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import UIKit
class HomeRouter:BaseRouter{
    
    override func destinationViewController(for destination: BaseRouter.Destination) -> UIViewController? {
        switch destination {
        case .goToScreen2(let strData):
            return gotoScreen2(strData: strData)
        default:
            return nil
        }
    }
}
