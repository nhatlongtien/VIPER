//
//  HomePresenter.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import UIKit
protocol HomePresenterLogic{
    func getDemoAPISucess()
    func getDemoAPIError(mess:String)
}
class HomePresenter: BasePresenter, HomePresenterLogic{
    var parentViewController: HomeViewController?{
        get {
            return (self.handleController as? HomeViewController)
        }
    }
    func getDemoAPISucess() {
        parentViewController?.router?.push(to: .goToScreen2(strData: "ABC"))
    }
    func getDemoAPIError(mess:String) {
        print(">>>>>>>>>>>>> EROR")
        UIAlertController.show(title: "Alert", message: mess, actionButtonTitle: ["OK"]) { buttonIndex in
            if buttonIndex == 1{
                print("OK")
            }
        }
    }
}
