//
//  HomeInteractor.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
protocol HomeInteractorLogic{
    
}
class HomeInteractor:BaseInteractor, HomeInteractorLogic{
    var presenter:HomePresenterLogic?
    func getDemoAPICheckPass(password:String){
        APIServicesFactory.demoAPI.checkPasword(password: password)
            .done { [self] (response) in
                print(response)
                presenter?.getDemoAPISucess()
            }
            .catch { [self] (error) in
                print(error)
                presenter?.getDemoAPIError(mess:error.localizedDescription)
            }
    }
}
