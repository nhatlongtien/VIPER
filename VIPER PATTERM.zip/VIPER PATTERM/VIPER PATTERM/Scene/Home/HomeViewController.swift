//
//  ViewController.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import UIKit

class HomeViewController: UIViewController {
    
    var router:HomeRouter?
    var presenter:HomePresenter?
    var interactor:HomeInteractor?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        router = HomeRouter(handleController: self)
        presenter = HomePresenter(handleController: self)
        interactor = HomeInteractor(handleController: self)
        interactor?.presenter = presenter
    }

    @IBAction func screen2BtnWasPressed(_ sender: Any) {
        interactor?.getDemoAPICheckPass(password: "0359386943")
        //router?.push(to: .goToScreen2(strData: "ABC"))
    }
    
}

