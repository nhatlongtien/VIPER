//
//  DemoAPIModel.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
class DemoAPIModel: BaseModel,Codability {
    var message: String
    
    enum CodingKeys:String,CodingKey
    {
        case message = "msg"
    }

    required init(from decoder: Decoder) throws {
        let values  = try decoder.container(keyedBy: CodingKeys.self)
        message = try values.decodeIfPresent(String.self, forKey: .message) ?? ""
    }
}
