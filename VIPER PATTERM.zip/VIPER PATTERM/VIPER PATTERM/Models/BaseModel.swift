//
//  BaseModel.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
class BaseModel:NSObject {
    
    
}
