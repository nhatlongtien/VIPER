//
//  Defaults.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/22/22.
//

import Foundation
import UIKit
/// Key For UserDefaults
///
/// - loginInfo: -Login
/// - voucherList: -Vouncher
/// - categories: -Categories
/// - centers: centers

enum UserDefaultKey:String{
    case loginInfo = "LoginInfo"
    case deviceToken = "deviceToken"
}

struct NotificationSettings: Codable {
    var status: Bool?
    var date: String?
}

class Defaults {
    
    static func saveValue(value:Any, forKey key: UserDefaultKey){
        UserDefaults.standard.set(value, forKey: key.rawValue)
    }
    
    static func getValue(forKey key: UserDefaultKey)->Any?{
        return UserDefaults.standard.object(forKey: key.rawValue)
    }
    
    static func saveObject(value:BaseModel, forKey key: UserDefaultKey){
        //Conver to data before save non-property list object
        let obj = value as? Codability
        let encodedData = obj?.encode()
        UserDefaults.standard.set(encodedData, forKey: key.rawValue)
    }
    
    static func saveObject(values:[BaseModel], forKey key: UserDefaultKey){
        //Conver to data before save non-property list object
        var arrEnncodedData:[Data] = []
        for item in values{
            let obj = item as? Codability
            let encodedData = obj?.encode()
            arrEnncodedData.append(encodedData!)
        }
        
        UserDefaults.standard.set(arrEnncodedData, forKey: key.rawValue)
    }
    
    static func saveDictionary<T: Codable>(value: T, forKey key: UserDefaultKey) {
        let encoder = JSONEncoder()
        let data = try? encoder.encode(value)
        UserDefaults.standard.set(data, forKey: key.rawValue)
    }
    
    static func getDictionary<T: Codable>(_ type: T.Type, with key: UserDefaultKey) -> T? {
        guard let data = UserDefaults.standard.value(forKey: key.rawValue) as? Data else { return nil }
        let decoder = JSONDecoder()
        return try? decoder.decode(type.self, from: data)
    }
    
    static func getObject(forKey key: UserDefaultKey) -> Data?{
        if let data = UserDefaults.standard.object(forKey: key.rawValue) as? Data{
            return data
        }
        return nil
    }
    
    static func getObjects(forKey key: UserDefaultKey) -> [Data]?{
        if let arrData = UserDefaults.standard.object(forKey: key.rawValue) as? [Data]{
            return arrData
        }
        return nil
    }
    
    static func getArrayString(forKey key: UserDefaultKey) -> [String]?{
        if let arrData = UserDefaults.standard.array(forKey: key.rawValue) as? [String]{
            return arrData
        }
        return nil
    }
    static func getObjectCodability<T: Codability>(forKey key: UserDefaultKey) -> T? {
        if let data = Defaults.getObject(forKey: key) {
            return T.decode(data: data)
        }
        return nil
    }
    
    static func getObjectsCodability<T: Codability>(forKey key: UserDefaultKey) -> [T]? {
        var arrT:[T] = []
        if let arrData = Defaults.getObjects(forKey: key){
            for data in arrData{
                let item = T.decode(data: data)
                arrT.append(item!)
            }
            return arrT
        }
        return nil
    }
    
    static func clearUserData(forKey key: UserDefaultKey){
        UserDefaults.standard.removeObject(forKey: key.rawValue)
        UserDefaults.standard.synchronize()
    }
    
//    static func clearDataCategories(){
//        Defaults.clearUserData(forKey: .categories)
//    }
}
