//
//  ErrorModel.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import Alamofire

class ErrorModel:BaseModel,Codability {
    private var message: String = ""
    private var code:Int = -1
    var error:CustomError?// = CustomError(code: -1, messageContent: "Unknown Error")
    enum CodingKeys:String,CodingKey
    {
        //Encoding/decoding will only include the properties defined in this enum, rest will be ignored
        case message = "msg"
        case code
    }
    required init(from decoder: Decoder) throws {

        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.message = try container.decodeIfPresent(String.self, forKey: .message) ?? "Unknown Error"
        self.code = try container.decodeIfPresent(Int.self, forKey: .code) ?? -1
        self.error = CustomError(code: self.code, messageContent: self.message)
    }
    
}

 class CustomError:NSError{
     var messageContent:String = ""
    
    init(code:Int, messageContent:String){
        super.init(domain: "APP.ERROR", code: code, userInfo: nil)
        self.messageContent = messageContent
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var localizedDescription: String{
        return messageContent
    }
    
    class func defaultError() ->CustomError{
        return CustomError(code: -1, messageContent: "Unknow error")
    }
}
class AppErrorHandler:NSError{
    
}
