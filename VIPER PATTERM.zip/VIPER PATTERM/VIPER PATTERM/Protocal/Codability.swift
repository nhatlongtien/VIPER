//
//  Codability.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import UIKit

protocol Codability: Codable {}

extension Codability {
    typealias T = Self
    func encode() -> Data? {
        return try? JSONEncoder().encode(self)
    }
   
    
    func convertToString() ->String?{
        let jsonEncoder = JSONEncoder()
        jsonEncoder.outputFormatting = .prettyPrinted
        do {
            let jsonData = try jsonEncoder.encode(self)
            return String(data: jsonData, encoding: .utf8)
        } catch {
            return nil
        }
    }
    //==============================
    static func decode(data: Data) -> T? {
        return try? JSONDecoder().decode(T.self, from: data)
    }
    static func decode(jsonString:String) ->T?{
        if let jsonData = jsonString.data(using: .utf8)
        {
           return self.decode(data: jsonData)
        }
        return nil
    }
    static func decode(json:[String:Any]) ->T?{
        if let jsonData = try? JSONSerialization.data(withJSONObject: json, options: .prettyPrinted){
            return self.decode(data: jsonData)
        }
        return nil
        
        
    }
    //=============================
    func decode(data: Data) -> T? {
        return try? JSONDecoder().decode(T.self, from: data)
    }
    func decode(jsonString:String) ->T?{
        if let jsonData = jsonString.data(using: .utf8)
        {
            return self.decode(data: jsonData)
        }
        return nil
    }
    func decode(json:[String:Any]) ->T?{
        if let jsonData = try? JSONSerialization.data(withJSONObject: json, options: .prettyPrinted){
            return self.decode(data: jsonData)
        }
        return nil
        
        
    }
}
