//
//  Reusable.swift
//  VIPER PATTERM
//
//  Created by Danny Vu on 7/20/22.
//

import Foundation
import UIKit
protocol Reusable: class {
    static var defaultReuseIdentifier: String { get }
}

extension Reusable where Self: UIView {
    static var defaultReuseIdentifier: String {
        return String(describing: self)
    }
}
